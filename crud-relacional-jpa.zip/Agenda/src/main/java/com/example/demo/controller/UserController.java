package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Usuario;
import com.example.demo.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping("/")
	public String home() {
		return "interface";
	}

	@PostMapping("/addUser")
	public ResponseEntity<Usuario> addUser(@RequestBody Usuario user) {
		Usuario createUser = userService.createUser(user);
		return ResponseEntity.ok().body(createUser);
	}

	@PostMapping("/addUsers")
	public List<Usuario> addUsers(@RequestBody List<Usuario> users) {
		return userService.createUsers(users);
	}

	@GetMapping("/user/{id}")
	public Usuario getUserById(@PathVariable int id) {
		return userService.getUserById(id);
	}

	@GetMapping("/users")
	public ResponseEntity<List<Usuario>> getAllUsers() {
	    List<Usuario> users = userService.getUsers();
	    return ResponseEntity.ok().body(users);
	}

	@PutMapping("/updateUser") 
	public ResponseEntity<Usuario> updateUser(@RequestBody Usuario user) {
	    Usuario updatedUser = userService.updateUser(user); 
	    return ResponseEntity.ok().body(updatedUser);
	}

	@DeleteMapping("/User/{id}")
	public String deleteUser(@PathVariable int id) {
		return userService.deleteUserById(id);
	}
}
