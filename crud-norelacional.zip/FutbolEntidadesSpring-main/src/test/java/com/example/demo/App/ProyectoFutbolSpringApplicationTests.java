package com.example.demo.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFutbolSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
